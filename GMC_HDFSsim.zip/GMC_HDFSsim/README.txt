*********** Written by Ali Mortazavi ****************

software name: GMC-HDFSSim
	      (Geographical Multi-Clustered Hadoop Distributed File System Simulator)

*************** description *************************
This software is a simulator for geographical multi-clustered distributed storage systems.
since there is not a complete and comprehensive simulator for algorithm which is written 
for data management in a distributed storage system, we try to develope HDFSSim (written 
by Corentone) and introduce a simulator for these types of algorithms. such as replication 
algorithm for multi data centers storage systems.
This simulator is useful for researcher. due to the absence simulator for replication algorithms 
in distributed storage systems, researcher had to write all code, 0 to 100. so this simulator is 
published. researcher can use this simulator and modify it according to their Requirement.
GMC-HDFSSim contains some essential classes such as data center, data item, workload, data nodes and
replication manager.
for more information about thsese classes read the document file in path "dist/javadoc/index.html"