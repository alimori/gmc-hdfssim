/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with this
 * work for additional information regarding copyright ownership. The ASF
 * licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package hdfs.replicationsimulator;

import java.io.*;
import java.util.*;
import java.sql.Time;

/**
 * *************************************************
 * PendingReplicationBlocks does the bookkeeping of all blocks that are getting
 * replicated.
 *
 * It does the following: 1) record blocks that are getting replicated at this
 * instant. 2) a coarse grain timer to track age of replication request 3) a
 * thread that periodically identifies replication-requests that never made it.
 *
 **************************************************
 * @author in the main source of this class was not written name of author,
 * this class manipulate by Ali Mortazavi
 */
class PendingReplicationBlocks {

    private Map<BlockInfo, PendingBlockInfo> pendingReplications;
    //private ArrayList<BlockInfo> timedOutItems;
    private List<BlockInfo> timedOutItems;
    Daemon timerThread = null;
    private volatile boolean fsRunning = true;

    //
    // It might take anywhere between 5 to 10 minutes before
    // a request is timed out.
    //
    private long timeout = 5 * 60 * 1000;
    private long defaultRecheckInterval = 5 * 60 * 1000;

    PendingReplicationBlocks(long timeoutPeriod) {
        if (timeoutPeriod > 0) {
            this.timeout = timeoutPeriod;
        }
        init();
    }

    PendingReplicationBlocks() {
        init();
    }

    void init() {
        pendingReplications = new HashMap<>();
        timedOutItems = new ArrayList<>();
        this.timerThread = new Daemon(new PendingReplicationMonitor());
        timerThread.start();
    }

    /**
     * Add a block to the list of pending Replications
     */
    void add(BlockInfo block) {
        synchronized (pendingReplications) {
            PendingBlockInfo found = pendingReplications.get(block);
            if (found == null) {
                pendingReplications.put(block, new PendingBlockInfo());
            } else {
//                found.incrementReplicas(numReplicas);
                found.setTimeStamp();
            }
        }
    }

    /**
     * One replication request for this block has finished. Decrement the number
     * of pending replication requests for this block.
     */
    void remove(BlockInfo block) {
        synchronized (pendingReplications) {
            PendingBlockInfo found = pendingReplications.get(block);
            if (found != null) {
                //FSNamesystem.LOG.debug("Removing pending replication for block" + block);
//                found.decrementReplicas();
                
                pendingReplications.remove(block);
            }
        }
    }

    /**
     * The total number of blocks that are undergoing replication
     */
    int size() {
        return pendingReplications.size();
    }

    int getReplica(BlockInfo block){
       synchronized (pendingReplications) {
            PendingBlockInfo found = pendingReplications.get(block);
            if (found != null) {
                return 1;
            }
        }
        return 0;
    }
    
    /**
     * How many copies of this block is pending replication?
     */
//    int getNumReplicas(BlockInfo block) {
//        synchronized (pendingReplications) {
//            PendingBlockInfo found = pendingReplications.get(block);
//            if (found != null) {
//                return found.getNumReplicas();
//            }
//        }
//        return 0;
//    }

    /**
     * Returns a list of blocks that have timed out their replication requests.
     * Returns null if no blocks have timed out.
     */
//    BlockInfo[] getTimedOutBlocks() {
//        synchronized (timedOutItems) {
//            if (timedOutItems.size() <= 0) {
//                return null;
//            }
//            BlockInfo[] blockList = timedOutItems.toArray(
//                    new BlockInfo[timedOutItems.size()]);
//            timedOutItems.clear();
//            return blockList;
//        }
//    }
    
      List<BlockInfo> getTimedOutBlocks() {
        synchronized (timedOutItems) {
            if (timedOutItems.size() <= 0) {
                return null;
            }
            List<BlockInfo> blockList = new ArrayList<>();
            for (BlockInfo blockInfo : timedOutItems) {
                blockList.add(blockInfo);
            }
            timedOutItems.clear();
            return blockList;
        }
    }
    

    /**
     * An object that contains information about a block that is being
     * replicated. It records the timestamp when the system started replicating
     * the most recent copy of this block. It also records the number of
     * replication requests that are in progress.
     */
    static class PendingBlockInfo {

        private long timeStamp;
//        private int numReplicasInProgress;

        PendingBlockInfo() {
            this.timeStamp = Node.now();
//            this.numReplicasInProgress = numReplicas;
        }

        long getTimeStamp() {
            return timeStamp;
        }

        void setTimeStamp() {
            timeStamp = Node.now();
        }

//        void incrementReplicas(int increment) {
//            numReplicasInProgress += increment;
//        }
//        void decrementReplicas() {
//            numReplicasInProgress--;
//            assert (numReplicasInProgress >= 0);
//        }
//        int getNumReplicas() {
//            return numReplicasInProgress;
//        }
    }

    /*
     * A periodic thread that scans for blocks that never finished
     * their replication request.
     */
    class PendingReplicationMonitor implements Runnable {

        public void run() {
            while (fsRunning) {
                long period = Math.min(defaultRecheckInterval, timeout);
                try {
                    pendingReplicationCheck();
                    Thread.sleep(period);
                } catch (InterruptedException ie) {
                    /*FSNamesystem.LOG.debug(
                     "PendingReplicationMonitor thread received exception. " + ie);*/
                }
            }
        }

        /**
         * Iterate through all items and detect timed-out items
         */
        void pendingReplicationCheck() {
            synchronized (pendingReplications) {
                Iterator iter = pendingReplications.entrySet().iterator();
                long now = Node.now();
                //FSNamesystem.LOG.debug("PendingReplicationMonitor checking Q");
                while (iter.hasNext()) {
                    Map.Entry entry = (Map.Entry) iter.next();
                    PendingBlockInfo pendingBlock = (PendingBlockInfo) entry.getValue();
                    if (now > pendingBlock.getTimeStamp() + timeout) {
                        BlockInfo block = (BlockInfo) entry.getKey();
                        synchronized (timedOutItems) {
                            timedOutItems.add(block);
                        }
                        /*FSNamesystem.LOG.warn(
                         "PendingReplicationMonitor timed out block " + block);*/
                        iter.remove();
                    }
                }
            }
        }
    }

    /*
     * Shuts down the pending replication monitor thread.
     * Waits for the thread to exit.
     */
    void stop() {
        fsRunning = false;
        timerThread.interrupt();
        try {
            timerThread.join(3000);
        } catch (InterruptedException ie) {
        }
    }

    /**
     * Iterate through all items and print them.
     */
    void metaSave(PrintWriter out) {
        synchronized (pendingReplications) {
            out.println("Metasave: Blocks being replicated: "
                    + pendingReplications.size());
            Iterator iter = pendingReplications.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry entry = (Map.Entry) iter.next();
                PendingBlockInfo pendingBlock = (PendingBlockInfo) entry.getValue();
                BlockInfo block = (BlockInfo) entry.getKey();
                out.println(block
                        + " StartTime: " + new Time(pendingBlock.timeStamp)
                        + " NumReplicaInProgress: "
                        + 1);
            }
        }
    }
    /**
     * Current system time.
     *
     * @return current time in msec.
     *
     * static long now() { return System.currentTimeMillis(); }
     */
}
